Hello everyone!
Thank you for downloading my 3d model!
This model was created in 3DS MAX 2016 and compatible with versions 2013+
Other available formats include FBX, 3DS, and OBJ.

**For use in Unity3D: please download the FBX file and import the textures folder into Unity first, then the model.

"One or more textures on this 3D model have been created with photographs from Textures.com. These photographs may not be redistributed by default; please visit www.textures.com for more information."